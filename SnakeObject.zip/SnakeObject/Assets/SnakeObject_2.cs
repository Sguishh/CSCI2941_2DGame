﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class SnakeObject_2 : MonoBehaviour {
	//Default Movement Direction
	Vector2 direction = Vector2.right;
	bool ate = false;
	public GameObject tailPrefab;
	public List<Transform> tail_2 = new List<Transform>();
	int tailCount = 0;

	// Use this for initialization
	void Start () {
		//Move snake every 200ms
		InvokeRepeating ("Move", 0.2f, 0.2f);
	}

	// Update is called once per frame
	void Update () {
		if (Input.GetKey (KeyCode.D)) {
			ate = true;
			direction = Vector2.right;
		} else if (Input.GetKey (KeyCode.S)) {
			direction = -Vector2.up;    // '-up' means 'down'
		} else if (Input.GetKey (KeyCode.A)) {
			direction = -Vector2.right; // '-right' means 'left'
		} else if (Input.GetKey (KeyCode.W)) {
			direction = Vector2.up;
		}
	}

	void Move () {
		Vector2 curPos = transform.position;

		//Move in another direction
		//Adding vector to position
		transform.Translate(direction);

		if (ate) {
			GameObject tailTemp = (GameObject)Instantiate (tailPrefab, 
				curPos, Quaternion.identity);

			tailTemp.name = "Tail2Name" + tailCount;

			tail_2.Insert (0, tailTemp.transform);
			tailCount++;
			ate = false;
		}
		else if (tail_2.Count > 0) {
			tail_2.Last ().position = curPos;

			tail_2.Insert (0, tail_2.Last ());
			tail_2.RemoveAt (tail_2.Count - 1);
		}
	}

	void OnTriggerEnter2D(Collider2D coll) {
		if (coll.name.StartsWith("FoodPrefab")) {
			ate = true;

			Destroy(coll.gameObject);
		}
		else if (coll.name.StartsWith("TailName")){
			GameObject snake1 = GameObject.FindWithTag ("Snake1");
			SnakeObject snakeScript = snake1.GetComponent<SnakeObject> ();
			int index = snakeScript.tail.IndexOf (coll.transform);
			int tCount = snakeScript.tail.Count;
			for(int i = 0; i <= (tCount - index); i++){
				GameObject toDestroy = snakeScript.tail.Last ().gameObject;
				snakeScript.tail.RemoveAt(snakeScript.tail.Count - 1);
				Destroy (toDestroy);
			}
		}
	}
}
