﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class SnakeObject_2 : MonoBehaviour {
	//Default Movement Direction
	Vector2 direction = Vector2.right;
	bool ate = false;
	public GameObject tailPrefab;
	List<Transform> tail = new List<Transform>();

	// Use this for initialization
	void Start () {
		//Move snake every 200ms
		InvokeRepeating ("Move", 0.2f, 0.2f);
	}

	// Update is called once per frame
	void Update () {
		if (Input.GetKey(KeyCode.D))
			direction = Vector2.right;
		else if (Input.GetKey(KeyCode.S))
			direction = -Vector2.up;    // '-up' means 'down'
		else if (Input.GetKey(KeyCode.A))
			direction = -Vector2.right; // '-right' means 'left'
		else if (Input.GetKey(KeyCode.W))
			direction = Vector2.up;
	}

	void Move () {
		Vector2 curPos = transform.position;

		//Move in another direction
		//Adding vector to position
		transform.Translate(direction);

		if (ate) {
			GameObject tailTemp = (GameObject)Instantiate (tailPrefab, 
				curPos, Quaternion.identity);

			tail.Insert (0, tailTemp.transform);
			ate = false;
		}
		else if (tail.Count > 0) {
			tail.Last ().position = curPos;

			tail.Insert (0, tail.Last ());
			tail.RemoveAt (tail.Count - 1);
		}
	}

	void OnTriggerEnter2D(Collider2D coll) {
		if (coll.name.StartsWith("FoodPrefab")) {
			ate = true;

			Destroy(coll.gameObject);
		}
		else {
			//Run into other snake or itself
		}
	}
}
