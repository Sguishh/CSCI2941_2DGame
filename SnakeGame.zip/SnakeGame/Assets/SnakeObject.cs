﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class SnakeObject : MonoBehaviour {
	//Default Movement Direction
	Vector2 direction = Vector2.right;
	bool ate = false;
	public GameObject tailPrefab;
	public List<Transform> tail = new List<Transform>();
	int tailCount = 0;
    bool isDied = false;

	// Use this for initialization
	void Start () {
		//Move snake every 200ms
		InvokeRepeating ("Move", 0.2f, 0.2f);
	}

    // Update is called once per frame
    void Update()
    {
        if (!isDied)
        {
            if (Input.GetKey(KeyCode.RightArrow))
            {
                direction = Vector2.right;
            }
            else if (Input.GetKey(KeyCode.DownArrow))
            {
                direction = -Vector2.up;    // '-up' means 'down'
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                direction = -Vector2.right; // '-right' means 'left'
            }
            else if (Input.GetKey(KeyCode.UpArrow))
            {
                direction = Vector2.up;
            }
        }
        else
        {
            if (Input.GetKey(KeyCode.R))
            {
                //clear the tail
				int tCount = tail.Count;
				for(int i = 0; i < tCount; i++){
					GameObject toDestroy = tail.Last ().gameObject;
					tail.RemoveAt(tail.Count - 1);
					Destroy (toDestroy);
				}

                //reset to origin
                transform.position = new Vector2(-50, 0);

                //make snake alive
                isDied = false;
            }
        }
    }

    void Move()
    {
        if (!isDied)
        {

            Vector2 curPos = transform.position;

            //Move in another direction
            //Adding vector to position
            transform.Translate(direction);


            if (ate)
            {
                GameObject tailTemp = (GameObject)Instantiate(tailPrefab,
                    curPos, Quaternion.identity);

                tailTemp.name = "TailName" + tailCount;

                tail.Insert(0, tailTemp.transform);
                ate = false;
            }
            else if (tail.Count > 0)
            {
                tail.Last().position = curPos;

                tail.Insert(0, tail.Last());
                tail.RemoveAt(tail.Count - 1);
            }
        }
    }

	void OnTriggerEnter2D(Collider2D coll) {
		if (coll.name.StartsWith("FoodPrefab")) {
			ate = true;

			Destroy(coll.gameObject);
		}
		else if (coll.name.StartsWith("Tail2Name")){
			GameObject snake2 = GameObject.FindWithTag ("Snake2");
			SnakeObject_2 snake2Script = snake2.GetComponent<SnakeObject_2> ();
			int index = snake2Script.tail_2.IndexOf (coll.transform);
			int tCount = snake2Script.tail_2.Count;
			for(int i = 0; i <= (tCount - index); i++){
				GameObject toDestroy = snake2Script.tail_2.Last ().gameObject;
				snake2Script.tail_2.RemoveAt(snake2Script.tail_2.Count - 1);
				Destroy (toDestroy);
			}
		}
		else if(coll.name.StartsWith("Head_2"))
        {
            isDied = true;
        }
	}
}
