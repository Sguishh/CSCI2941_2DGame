﻿using UnityEngine;
using System.Collections;

public class SpawnPowerup : MonoBehaviour {
    // Food Prefab
    public GameObject PowerupPrefab;

    // Borders
    public Transform borderTop;
    public Transform borderBottom;
    public Transform borderLeft;
    public Transform borderRight;

    // Use this for initialization
    void Start () {
        // Spawn food every 4 seconds, starting in 3
        InvokeRepeating("PowerupSpawn", 6, 6);
    }

    // Spawn one powerup
    void PowerupSpawn() {
        // x position near the middle
        int x = (int)Random.Range(-15,
                                  15);

        // y position near the middle
        int y = (int)Random.Range(-5,
                                  5);

        // Instantiate the powerup at (x, y)
        Instantiate(PowerupPrefab,
                    new Vector2(x, y),
                    Quaternion.identity); // default rotation
    }
}