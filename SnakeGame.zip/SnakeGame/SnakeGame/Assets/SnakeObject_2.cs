﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class SnakeObject_2 : MonoBehaviour {
	//Default Movement Direction
	Vector2 direction = Vector2.right;
    bool powered = false;
    bool powerTimer = false;
	bool ate = false;
	public GameObject tailPrefab;
	public List<Transform> tail_2 = new List<Transform>();
	int tailCount = 0;
    bool isDied = false;

	// Use this for initialization
	void Start () {
		//Move snake every 200ms
		InvokeRepeating ("Move", 0.2f, 0.2f);
	}

    // Update is called once per frame
    void Update()
    {
        if (!isDied)
        {

            if (Input.GetKey(KeyCode.D))
            {
                direction = Vector2.right;
            }
            else if (Input.GetKey(KeyCode.S))
            {
                direction = -Vector2.up;    // '-up' means 'down'
            }
            else if (Input.GetKey(KeyCode.A))
            {
                direction = -Vector2.right; // '-right' means 'left'
            }
            else if (Input.GetKey(KeyCode.W))
            {
                direction = Vector2.up;
            }
            else if (powered == true)
            {
                InvokeRepeating("Move", 0.2f, 0.2f);
                if(powerTimer == true)
                {
                    Invoke("PowerDown", 5f);
                }
                powered = false;
            }
        }
        if (isDied)
        {
            if (Input.GetKey(KeyCode.R))
            {
                //clear the tail
                int tCount = tail_2.Count;
                for (int i = 0; i < tCount; i++)
                {
                    GameObject toDestroy = tail_2.Last().gameObject;
                    tail_2.RemoveAt(tail_2.Count - 1);
                    Destroy(toDestroy);
                }
                Score1.score = 0;
                //reset to origin
                transform.position = new Vector2(50, 0);

                //make snake alive
                isDied = false;
            }
        }
    }

    void Move()
    {
        if (!isDied)
        {

            Vector2 curPos = transform.position;

            //Move in another direction
            //Adding vector to position
            transform.Translate(direction);

            if (ate)
            {
                GameObject tailTemp = (GameObject)Instantiate(tailPrefab,
                    curPos, Quaternion.identity);

                tailTemp.name = "Tail2Name" + tailCount;

                tail_2.Insert(0, tailTemp.transform);
                ate = false;
                Score1.score++;
            }
            else if (tail_2.Count > 0)
            {
                tail_2.Last().position = curPos;

                tail_2.Insert(0, tail_2.Last());
                tail_2.RemoveAt(tail_2.Count - 1);
            }
        }
    }

	void OnTriggerEnter2D(Collider2D coll) {
        if (coll.name.StartsWith("PowerupPrefab"))
        {
            powered = true;
            powerTimer = true;
            Destroy(coll.gameObject);
        }
        else if (coll.name.StartsWith("FoodPrefab")) {
			ate = true;

			Destroy(coll.gameObject);
		}
		else if (coll.name.StartsWith("TailName")){
			GameObject snake1 = GameObject.FindWithTag ("Snake1");
			SnakeObject snakeScript = snake1.GetComponent<SnakeObject> ();
			int index = snakeScript.tail.IndexOf (coll.transform);
			int tCount = snakeScript.tail.Count;
			for(int i = 0; i <= (tCount - index); i++){
				GameObject toDestroy = snakeScript.tail.Last ().gameObject;
				snakeScript.tail.RemoveAt(snakeScript.tail.Count - 1);
				Destroy (toDestroy);
                Score2.score--;
                Score1.score++;
            }

        }
        else if (coll.name.StartsWith ("Head_1"))
        {
            isDied = true;
        }
        else if (coll.name.StartsWith("Bottom_Horizontal"))
        {
            transform.position = new Vector2(transform.position.x, 28);
        }
        else if (coll.name.StartsWith("Top_Horizontal"))
        {
            transform.position = new Vector2(transform.position.x, -28);
        }
        else if (coll.name.StartsWith("Left_Vertical"))
        {
            transform.position = new Vector2(68, transform.position.y);
        }
        else if (coll.name.StartsWith("Right_Vertical"))
        {
            transform.position = new Vector2(-68, transform.position.y);
        }
    }
    void PowerDown()
    {
        CancelInvoke("Move");
        InvokeRepeating("Move", 0.2f, 0.2f);
    }
}
