﻿using UnityEngine;
using UnityEngine.UI;

public class Score2 : MonoBehaviour
{

    public Text scoreText;
    public static int score;

    void Start()
    {
        score = 0;
    }

    // Update is called once per frame
    void Update()
    {
        scoreText.text = "Red Score: " + score.ToString();
    }

}
